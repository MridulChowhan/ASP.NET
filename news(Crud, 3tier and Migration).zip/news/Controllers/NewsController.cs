﻿using BLL.DTOs;
using BLL.Services;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Net;
using System.Net.Http;
using System.Web.Http;

namespace news.Controllers
{
    public class NewsController : ApiController
    {
        [HttpGet]
        [Route("api/news/all")]
        public HttpResponseMessage GetAll()
        {
            var data = NewsService.GetAll();
            return Request.CreateResponse(HttpStatusCode.OK, data);
        }
        [HttpGet]
        [Route("api/news/{id}")]
        public HttpResponseMessage Get(int id)
        {
            var data = NewsService.Get(id);
            return Request.CreateResponse(HttpStatusCode.OK, data);
        }
        [HttpPost]
        [Route("api/news/create")]
        public HttpResponseMessage Create(NewsDTO s)
        {
            NewsService.Create(s);
            return Request.CreateResponse(HttpStatusCode.OK);
        }

        [HttpPut]
        [Route("api/news/update/{id}")]
        public HttpResponseMessage Update(int id, NewsDTO s)
        {
            var result = NewsService.Update(id, s);
            if (result)
            {
                return Request.CreateResponse(HttpStatusCode.OK, "News updated successfully");
            }
            return Request.CreateResponse(HttpStatusCode.NotFound, "News not found");
        }


        [HttpDelete]
        [Route("api/news/delete/{id}")]
        public HttpResponseMessage Delete(int id)
        {
            var result = NewsService.Delete(id);
            if (result)
            {
                return Request.CreateResponse(HttpStatusCode.OK, "News deleted successfully");
            }
            return Request.CreateResponse(HttpStatusCode.NotFound, "News not found");
        }

        [HttpGet]
        [Route("api/news/search")]
        public HttpResponseMessage Search([FromUri] string title = null, [FromUri] string category = null, [FromUri] DateTime? date = null)
        {
            var data = NewsService.Search(title, category, date);
            if (data.Any())
            {
                return Request.CreateResponse(HttpStatusCode.OK, data);
            }
            return Request.CreateResponse(HttpStatusCode.NotFound, "No matching news found");
        }

    }
}
