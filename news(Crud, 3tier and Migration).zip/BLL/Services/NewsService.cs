﻿using AutoMapper;
using BLL.DTOs;
using DAL.EF;
using DAL.Repos;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace BLL.Services
{
    public class NewsService
    {
        public static List<NewsDTO> GetAll()
        {
            var srepo = new NewsRepo();
            var data = srepo.Get();
            var config = new MapperConfiguration(cfg => {
                cfg.CreateMap<News, NewsDTO>();
            });
            var mapper = new Mapper(config); ;
            var ret = mapper.Map<List<NewsDTO>>(data);

            return ret;

        }
        public static NewsDTO Get(int id)
        {
            var srepo = new NewsRepo();
            var data = srepo.Get(id);
            var config = new MapperConfiguration(cfg => {
                cfg.CreateMap<News, NewsDTO>();
            });
            var mapper = new Mapper(config); ;
            var ret = mapper.Map<NewsDTO>(data);

            return ret;

        }
        public static void Create(NewsDTO s)
        {
            var config = new MapperConfiguration(cfg => {
                cfg.CreateMap<NewsDTO, News>();
            });
            var mapper = new Mapper(config); ;
            var st = mapper.Map<News>(s);
            var repo = new NewsRepo();
            repo.Create(st);

        }
        public static bool Update(int id, NewsDTO s)
        {
            var repo = new NewsRepo();
            var existingNews = repo.Get(id);
            if (existingNews == null)
            {
                return false;
            }

            var config = new MapperConfiguration(cfg =>
            {
                cfg.CreateMap<NewsDTO, News>();
            });
            var mapper = new Mapper(config);
            var updatedNews = mapper.Map<News>(s);
            updatedNews.Id = id;
            repo.Update(updatedNews);
            return true;
        }


        public static bool Delete(int id)
        {
            var repo = new NewsRepo();
            var existingNews = repo.Get(id);
            if (existingNews == null)
            {
                return false;
            }
            repo.Delete(id);
            return true;
        }
        public static List<NewsDTO> Search(string title, string category, DateTime? date)
        {
            var repo = new NewsRepo();
            var data = repo.Search(title, category, date);
            var config = new MapperConfiguration(cfg => {
                cfg.CreateMap<News, NewsDTO>();
            });
            var mapper = new Mapper(config);
            var result = mapper.Map<List<NewsDTO>>(data);

            return result;
        }

    }
}
